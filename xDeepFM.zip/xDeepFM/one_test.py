from xDeepFM import *
import numpy as np
c=[[-43244.31843972],
   [-43244.31843972]]
d=[[28830.21229314]]
print(np.matmul(c,d))