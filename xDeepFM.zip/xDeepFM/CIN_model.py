import numpy as np
import xDeepFM.LR_model as LR
from xDeepFM import *

class CIN_model(object):
    def __init__(self):
        self.layerList=[]
        self.Weights=[]
        self.biase=[]
        return
    def append(self,CIN_Layer):
        self.layerList.append(CIN_Layer)
    def build_model(self,inputData):
        if len(self.layerList)==0:
            print("no layer is detected！")
            return
        else:
            for index in range(len(self.layerList)):
                if index==0:
                    w_map=np.zeros((inputData.shape[0]*inputData.shape[0],self.layerList[0].H))+1
                else:
                    w_map=np.zeros(())


class CIN_Layer(object):
    def __init__(self,H):
        self.H=H
        return


